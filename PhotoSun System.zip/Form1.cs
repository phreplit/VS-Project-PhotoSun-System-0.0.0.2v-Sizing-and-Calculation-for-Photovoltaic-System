﻿
//  Author: PHNO - Technologist | Postgraduate in Photovoltaic Solar Energy
//  Release Date: 03/10/2024
//  Version: 0.0.0.2v
//  Replit: @PHNO, @PHREPLIT
//  E-mail: phreplit@gmail.com

// Software: PhotoSun - System - 0.0.0.2v - Sizing and Calculation for Photovoltaic System, with GUI [graphical interface] and compilation in desktop environment.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            this.Text = "PhotoSun - System - 0.0.0.2v - Sizing and Calculation for Photovoltaic System";


            // campo, metodo
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear(); // call clear method
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();
            textBox15.Clear();
            textBox16.Clear();
            textBox17.Clear();
            textBox18.Clear();
            textBox19.Clear();
            textBox20.Clear();
            textBox21.Clear();
            textBox22.Clear();

        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Text = "Info";
            // classe, metodo, string(texto)
            MessageBox.Show("Info\n"
                + "\nBasic Conversion - To convert volts to watts we multiply the volts by 10."
                + "\nBasic Conversion - To convert watts to volts we divide the watts by 10."
                + "\nTo calculate the power of the modules, we multiply the nominal power of the module by the number of modules."
                + "\nTo calculate weekly generation we use the calculation (power of modules) x (hours per day) x (days per week)."
                + "\nTo calculate the monthly generation we use the calculation (power of the modules) x (hours per day) x (days per month)."
                + "\nTo calculate the annual generation we use the calculation (power of the modules) x (hours per day) x (days per year)."
                + "\nTo calculate and size the number of modules that make a solar panel, we use the following calculation:"
                + "\nCalculated system power (Pfv[BR]) in watts divided by the nominal module power in watts = the Number of Modules."
                + "\nTo convert 1kwh to 1wh just do the calculation e.g.: 73kwh to wh will be 73000wh. So it will be 1kwh = 1000wh.");

        }

        private void button16_Click(object sender, EventArgs e)
        {
            this.Text = "About";
            MessageBox.Show("About\n" + "\nSoftware: PhotoSun - System - 0.0.0.2v - Sizing and Calculation for Photovoltaic System \n" + "\nAuthor: PHNO" + "\nRelease Date: 03/10/2024" + "\nVersion: 0.0.0.2v" + "\nReplit: @PHNO, @PHREPLIT" + "\nE-mail: phreplit@gmail.com");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int var1))
            {
                int var2 = 10;
                int mult = var1 * var2;

                textBox2.Text = ("" + mult);
            }
            else // if dont do the calc, so then show error message.
            {
                textBox2.Text = "Error. enter required field.";
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox3.Text, out int var3))
            {
                int var4 = 10;
                int div = var3 / var4;

                textBox4.Text = ("" + div);
            }
            else
            {
                textBox4.Text = "Error. enter required field.";
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox5.Text, out int var5) && int.TryParse(textBox6.Text, out int var6))
            {
                int mult2 = var5 * var6;

                textBox7.Text = ("" + mult2);
            }
            else
            {
                textBox7.Text = "Error. enter required field.";
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox8.Text, out int var7) && int.TryParse(textBox9.Text, out int var8) && int.TryParse(textBox10.Text, out int var9))
            {
                int var10 = 1000;
                int mult3 = var7 * var8 * var9;
                int result = mult3 / var10;

                textBox11.Text = ("" + result);
            }
            else
            {
                textBox11.Text = "Error. enter required field.";
            }

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox12.Text, out int var11) && int.TryParse(textBox13.Text, out int var12) && int.TryParse(textBox14.Text, out int var13))
            {
                int var14 = 1000;
                int mult4 = var11 * var12 * var13;
                int result2 = mult4 / var14;

                textBox15.Text = ("" + result2);
            }
            else
            {
                textBox15.Text = "Error. enter required field.";
            }

        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox16.Text, out int var15) && int.TryParse(textBox17.Text, out int var16) && int.TryParse(textBox18.Text, out int var17))
            {
                int var18 = 1000;
                int mult5 = var15 * var16 * var17;
                int result3 = mult5 / var18;

                textBox19.Text = ("" + result3);
            }
            else
            {
                textBox19.Text = "Error. enter required field.";
            }

        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox20.Text, out int var19) && int.TryParse(textBox21.Text, out int var20))
            {
                int div2 = var19 / var20;

                textBox22.Text = ("" + div2);
            }
            else
            {
                textBox22.Text = "Error. enter required field.";
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int var1))
            {
                this.Text = "PhotoSun - System - 0.0.0.2v - Sizing and Calculation for Photovoltaic System";


                // campo, metodo
                textBox1.Clear();
                textBox2.Clear();
            }
            else // if dont do the calc, so then show error message.
            {
                textBox2.Text = "Error. nothing to clear.";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox3.Text, out int var3))
            {
                this.Text = "PhotoSun - System - 0.0.0.2v - Sizing and Calculation for Photovoltaic System";


                // campo, metodo
                textBox3.Clear();
                textBox4.Clear();
            }
            else
            {
                textBox4.Text = "Error. nothing to clear.";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox5.Text, out int var5) && int.TryParse(textBox6.Text, out int var6))
            {
                this.Text = "PhotoSun - System - 0.0.0.2v - Sizing and Calculation for Photovoltaic System";


                // campo, metodo
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
            }
            else
            {
                textBox7.Text = "Error. nothing to clear.";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox8.Text, out int var7) && int.TryParse(textBox9.Text, out int var8) && int.TryParse(textBox10.Text, out int var9))
            {
                this.Text = "PhotoSun - System - 0.0.0.2v - Sizing and Calculation for Photovoltaic System";


                // campo, metodo
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
            }
            else
            {
                textBox11.Text = "Error. nothing to clear.";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox12.Text, out int var11) && int.TryParse(textBox13.Text, out int var12) && int.TryParse(textBox14.Text, out int var13))
            {
                this.Text = "PhotoSun - System - 0.0.0.2v - Sizing and Calculation for Photovoltaic System";


                // campo, metodo
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
            }
            else
            {
                textBox15.Text = "Error. nothing to clear.";
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox16.Text, out int var15) && int.TryParse(textBox17.Text, out int var16) && int.TryParse(textBox18.Text, out int var17))
            {
                this.Text = "PhotoSun - System - 0.0.0.2v - Sizing and Calculation for Photovoltaic System";


                // campo, metodo
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
            }
            else
            {
                textBox19.Text = "Error. nothing to clear.";
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox20.Text, out int var19) && int.TryParse(textBox21.Text, out int var20))
            {
                this.Text = "PhotoSun - System - 0.0.0.2v - Sizing and Calculation for Photovoltaic System";



                // campo, metodo
                textBox20.Clear();
                textBox21.Clear();
                textBox22.Clear();
            }
            else
            {
                textBox22.Text = "Error. nothing to clear.";
            }
        }
    }
}
